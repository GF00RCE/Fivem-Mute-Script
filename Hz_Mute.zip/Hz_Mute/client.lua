ESX = nil

Citzen.CreateThread(function()
  while ESX == nil do
  TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
  Wait(0)
  end

  while ESX.GetPlayerData().job == nil do
      Citzen.Wait(10)
  end

  PlayerData = ESX.GetPlayerData()
end)


RegisterNetEvent("muted")
AddEventHandler("muted", function(status)
  
  muted = status
  TmuePlayer()

end)


function TmuePlayer()


	Citzen.CreateThread(function()

		while muted do

			DisableControlAction(0, 245, true)
			DisableControlAction(0, 249, true)


      Citzen.Wait(0)
            
		end

	end)
end

function MuteMenu()

	ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'mute',
	{
		title = 'mute',
		align = 'top-left'
	}, function(data, menu)
		local re = tonumber(data.value)

		TriggerEvent('HazardDevelopment:setMuteStatus', re, true)
		menu.close()
	end, function(data, menu)
		menu.close()
	end)
end

function UnMuteMenu()

	ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'mute',
	{
		title = 'mute',
		align = 'top-left'
	}, function(data, menu)
		local er = tonumber(data.value)

		TriggerEvent('HazardDevelopment:setMuteStatus', er, false)
		menu.close()
	end, function(data, menu)
		menu.close()
	end)
		
end