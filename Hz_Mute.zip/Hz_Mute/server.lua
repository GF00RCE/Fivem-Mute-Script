ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterCommand('mute', function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.permission_level > 4 then
        if xPlayer.permission_level == 18 then
			return
		end
        TriggerClientEvent('chatMessage', source, '[WARRNING]', {255, 0, 0}, '^0Shoma ^2| ^1' .. GetPlayerName(args[1]) .. ' ^2| ^0ra mute Kardid')
        TriggerClientEvent('muted', args[1], true)
    else
        TriggerClientEvent('ChatMessage', source, '[WARRNING]', {255, 0, 0}, '^1Mikhay Mute Koni Bradar?')
    end
end)

RegisterCommand('unmute', function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer.permission_level > 4 then
        if xPlayer.permission_level == 18 then
            return
        end
        TriggerClientEvent('chatMessage', source, '[WARRNING]', {255, 0, 0}, '^0Shoma ^2' .. GetPlayerName(args[1]) .. ' ^0ra Unmute Kardid')

        TriggerClientEvent('muted', args[1], false)
    else
        TriggerClientEvent('ChatMessage', source, '[WARRNING]', {255, 0, 0}, '^1Mikhay Un Mute Koni Bradar?')
    end
end)